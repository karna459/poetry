"""
This subpackage's top-level Python module.

See:
1. https://realpython.com/documenting-python-code/
"""
