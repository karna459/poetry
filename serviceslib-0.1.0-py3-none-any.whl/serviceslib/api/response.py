"""
Defines classes for managing REST API requests and responses.

See:
1. https://betterprogramming.pub/9-python-dataclass-best-practices-to-improve-
   the-development-process-8a68df446580
2. https://changhsinlee.com/python-dataclass-mutable-default
"""
import json
from dataclasses import dataclass


# SECTION: CLASSES ========================================================== #


@dataclass
class Response:
    """
    A class modeling an Amazon Lambda function's response dictionary.

    Attributes
    ----------
    `body` : `str`
        A string representing the response. Can be a JSON string, HTML content,
        or any other data format.
        body.
    `status_code` : `int`
        An integer representing the HTTP status code for the response (`200`
        for a successful response, `404` for "Not found", etc).

    Methods
    -------
    to_dict()
        Returns a dictionary modeling a class instance. Renames the class
        instance's properties using camel case for the dictionary keys.
    """

    body: str
    status_code: int = 200

    def __post_init__(self):
        self.body = json.dumps(self.body)

    def to_dict(self) -> dict:
        """
        Returns a dictionary modeling a class instance. Renames the class
        instance's properties using camel case for the dictionary keys.

        Returns
        -------
        `dict`
            The class instance as a dictionary.
        """
        return {
            'statusCode': self.status_code,
            'body': self.body,
        }
