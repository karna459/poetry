"""
Defines classes for managing REST API requests and responses.

See:
1. https://betterprogramming.pub/9-python-dataclass-best-practices-to-improve-
   the-development-process-8a68df446580
2. https://changhsinlee.com/python-dataclass-mutable-default
"""
from dataclasses import dataclass
from dataclasses import field
from urllib.error import HTTPError
from urllib.error import URLError
from urllib.parse import urlencode
from urllib.parse import urljoin
from urllib.request import Request
from urllib.request import urlopen


# SECTION: CLASSES ========================================================== #


@dataclass
class Endpoint:
    """
    A class modeling a REST API endpoint.

    Attributes
    ----------
    `base_url` : `str`
        A string representing an endpoint's base URL.
    `path` : `str`
        A string representing an endpoint's path.
    `headers` : `dict`
        A dictionary representing an endpoint's HTTP headers.
    `params` : `dict`
        A dictionary representing an endpoint's query string parameters.
    `api_key` : `str`
        A string representing an endpoint's API key.
    `description` : `str`
        A string representing an endpoint's description.
    `query_interval_minutes` : `int`
        An integer representing the number of minutes to wait between requests.

    Methods
    -------
    `get()` : `str | None`
        Makes an HTTP GET request to a REST API endpoint.
    `post(data: dict)` : `str | None`
        Makes an HTTP POST request to a REST API endpoint.
    """

    # -- Attributes -- #

    # Required attributes
    base_url: str
    path: str

    # Optional attributes
    headers: dict = field(default_factory=dict)
    params: dict = field(default_factory=dict)
    api_key: str = field(default_factory=str)
    description: str = ''
    # TODO: Rename to `timeout` to align with `urlopen` parameter name.
    query_interval_minutes: int = 1440  # 24 hours

    # -- Properties -- #

    @property
    def query_string(self) -> str:
        """
        Returns a string representing the endpoint's query string.

        Returns
        -------
        `str`
            The endpoint's query string.
        """

        # Return the query string without percent-encoding special characters.
        return urlencode(self.params, safe='{}') or ''

    @property
    def url(self) -> str:
        """
        Returns a string representing the endpoint's full URL.

        Returns
        -------
        `str`
            The endpoint's full URL.
        """

        # Build the URL.
        url = str(self)
        if self.query_string != '':
            url += '?' + self.query_string

        # Return the URL.
        return url

    # -- Magic Methods -- #

    def __str__(self) -> str:
        """
        Renders a string representation of the endpoint: its URL minus its
        query string.

        Returns
        -------
        `str`
            The string representation.
        """

        # Try to join the endpoint's base URL and path.
        try:
            # Return the string representation.
            return urljoin(self.base_url, self.path)

        #  Handle value errors (e.g., malformed URL components).
        except ValueError as e:
            print('Value Error:', e)
            return ''

        #  Handle type errors (e.g., URL components with invalid data types).
        except TypeError as e:
            print('Type Error:', e)
            return ''

    # -- REST API Methods -- #

    def get(self) -> str | None:
        """
        Makes an HTTP GET request to a REST API endpoint.

        Returns
        -------
        `str | None`
            The response from the HTTP request as a JSON string, or `None` if
            an error occurs.
        """

        # Return the response.
        return self._make_request('GET')

    def post(
        self, data: dict,
    ) -> str | None:
        """
        Makes an HTTP POST request to a REST API endpoint.

        Parameters
        ----------
        `data` : `dict`
            A dictionary representing the request body.

        Returns
        -------
        `str | None`
            The response from the HTTP request as a JSON string, or `None` if
            an error occurs.
        """

        # Return the response.
        return self._make_request('POST', data=data)

    # -- Helper Methods -- #

    # TODO: Apply this docstring style for optional parameters to all methods.
    def _make_request(
        self, method: str, data: dict | None = None,
    ) -> str | None:
        """
        Returns the response from an HTTP request as a JSON string.

        Parameters
        ----------
        `method` : `str`
            The HTTP method to use for the request.
        `data` : `dict | None`, optional
            A dictionary representing the request body, by default `None`.

        Returns
        -------
        `str | None`
            The response from the HTTP request as a JSON string, or `None` if
            an error occurs.
        """

        # Try to make the request.
        try:
            if data:
                req = Request(
                    self.url,
                    data=urlencode(data).encode('utf-8'),
                    headers=self.headers,
                    method=method,
                )
            else:
                req = Request(
                    self.url,
                    headers=self.headers,
                    method=method,
                )

            # Make the request.
            with urlopen(req) as response:
                return response.read().decode('utf-8')

        # Handle value errors specific  (e.g., invalid HTTP headers).
        except ValueError as e:
            print('Value Error:', e)
            return None

        #  Handle type errors (e.g., HTTP headers with invalid data types).
        except TypeError as e:
            print('Type Error:', e)
            return None

        # Handle HTTP errors (e.g., 404 Not Found, 403 Forbidden)
        except HTTPError as e:
            print('HTTP Error:', e)
            print('URL Error code:', e.code)
            print('URL Error reason:', e.reason)
            return None

        # Handle URL errors (e.g., invalid URL format, network issues).
        except URLError as e:
            print('URL Error:', e)
            print('URL Error reason:', e.reason)
            return None

        # Handle unexpected errors.
        except Exception as e:
            print('Error:', e)
            return None
