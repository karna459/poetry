"""
This module defines classes for managing CRUD operations (create, read, update,
and delete) on Amazon DynamoDB database tables.

See:
1. https://docs.aws.amazon.com/code-library/latest/ug/python_3_dynamodb_code_
   examples.html
2. https://betterprogramming.pub/9-python-dataclass-best-practices-to-improve-
   the-development-process-8a68df446580
3. https://stackoverflow.com/questions/30866030/number-of-attributes-in-key-
   schema-must-match-the-number-of-attributes-defined-i
"""
from abc import ABC
from abc import abstractmethod
from dataclasses import dataclass
from typing import Any
from typing import Optional
from typing import Self

import boto3

from serviceslib.ops.state import State


# SECTION: CLASSES ========================================================== #


@dataclass
class TableManager(ABC):
    """
    This class enables CRUD operations (create, read, update delete) on an
    AWS DynamoDB table.

    Attributes:
    - region_name (str): AWS region name
    - table_name (str): AWS DynamoDB table name
    """

    # -- Attributes -- #

    region_name: str
    table_name: str

    # -- Properties -- #

    @property
    def dynamodb(self):
        """
        Returns an AWS DynamoDB resource.
        """

        # Return an AWS DynamoDB resource.
        return boto3.resource('dynamodb', region_name=self.region_name)

    @property
    def table(self):
        """
        Returns an AWS DynamoDB table.
        """

        # Return an AWS DynamoDB table.
        return self.dynamodb.Table(self.table_name)

    # -- CRUD Methods -- #

    @abstractmethod
    def create_table(self) -> None:
        """
        Creates an AWS DynamoDB table if it doesn't exist.
        """

        # Raise an error if this method is not implemented.
        raise NotImplementedError('Subclasses must implement this method.')

    def put_item(self, item: dict[str, str]):
        """
        Puts an item into the table.
        """

        self.table.put_item(Item=item)

    def get_item(self, key: dict[str, str]) -> Optional[dict[str, Any]]:
        """
        Gets an item from the AWS DynamoDB table based on the provided key.
        """

        # Get the item.
        response = self.table.get_item(Key=key)

        # Return the item or `None` if it doesn't exist.
        return response.get('Item', None)

    def update_item(
        self,
        key: dict[str, str],
        update_expression: str,
        expression_attribute_values: dict[str, str],
    ) -> None:
        """
        Updates an item in the AWS DynamoDB table based on the provided key,
        update expression, and attribute values.
        """

        # Update the item.
        self.table.update_item(
            Key=key,
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_attribute_values,
        )

    def delete_item(self, key: dict[str, str]) -> None:
        """
        Deletes an item from the AWS DynamoDB table based on the provided key.
        """

        # Delete the item.
        self.table.delete_item(Key=key)


class HistoricalTableManager(TableManager):
    """
    This class enables CRUD operations (create, read, update delete) on the
    AWS DynamoDB historical table.
    """

    # -- Magic Methods -- #

    # def __init__(self, region_name: str):
    #     super().__init__(
    #         table_name='HistoricalTable',
    #         region_name=region_name,
    #     )

    # -- CRUD Methods -- #

    def create_table(self) -> None:
        """
        Creates an AWS DynamoDB table in DynamoDB if it doesn't exist.
        """
        partition_key = 'services_end_time'

        table_attributes = [
            {
                'AttributeName': partition_key,
                'AttributeType': 'S',
            },

        ]

        key_schema = [
            {
                'AttributeName': partition_key,
                'KeyType': 'HASH',  # HASH -> partition key, RANGE -> sort key
            },
        ]

        table = self.dynamodb.create_table(
            TableName=self.table_name,
            KeySchema=key_schema,
            AttributeDefinitions=table_attributes,
            ProvisionedThroughput={
                'ReadCapacityUnits': 1,   # 0,
                'WriteCapacityUnits': 1,  # 0,
            },
        )
        table.meta.client.get_waiter('table_exists').wait(
            TableName=self.table_name,
        )


class IterationTableManager(TableManager):
    """
    This class enables CRUD operations (create, read, update delete) on the
    Amazon DynamoDB iteration table.
    """

    # -- Magic Methods -- #

    # def __init__(self, region_name: str):
    #     super().__init__(
    #         table_name='IterationTable',
    #         region_name=region_name,
    #     )

    # -- CRUD Methods -- #

    def create_table(self) -> None:
        """
        Creates an AWS DynamoDB table if it doesn't exist.
        """
        partition_key = 'services_end_time'

        table_attributes = [
            {
                'AttributeName': partition_key,
                'AttributeType': 'S',
            },
        ]

        key_schema = [
            {
                'AttributeName': partition_key,
                'KeyType': 'HASH',  # HASH -> partition key, RANGE -> sort key
            },
        ]

        table = self.dynamodb.create_table(
            TableName=self.table_name,
            KeySchema=key_schema,
            AttributeDefinitions=table_attributes,
            ProvisionedThroughput={
                'ReadCapacityUnits': 1,   # 0,
                'WriteCapacityUnits': 1,  # 0,
            },
        )
        table.meta.client.get_waiter('table_exists').wait(
            TableName=self.table_name,
        )


@dataclass
class TableItem:
    """
    A class modeling an AWS DynamoDB table item.

    Attributes
    ----------
    `services_start_time` : `str`
        The start time of an HTTP GET request.
    `services_end_time` : `str`
        The end time of an HTTP GET request.
    `endpoint_url` : `str`
        The REST API endpoint of an HTTP GET request.
    `query_page_count` : `str`
        The page count of an HTTP GET request.
    `query_page_identifier` : `str`
        An offset value used in an HTTP GET request to control pagination.
    """

    services_start_time: str
    services_end_time: str
    endpoint_url: str
    query_page_count: str
    query_page_identifier: str


@dataclass
class IterationTableItem(TableItem):
    """
    A class modeling an AWS DynamoDB iteration table item.

    Attributes
    ----------
    `next_query_update_since_datetime` : `str`
        TBD.
    """

    # -- Attributes -- #

    next_query_update_since_datetime: str

    # -- Class Methods -- #

    @classmethod
    def default(cls, datetime: str) -> Self:
        """
        Creates a default class instance.

        Parameters
        ----------
        `datetime` : `str`
            A string representing a datetime.

        Returns
        -------
        `Self`
            The class instance.
        """
        return cls(
            services_start_time='',
            services_end_time=' ',  # TODO: Consider using the Unix epoch here.
            endpoint_url='',
            query_page_count='0',
            query_page_identifier='0',
            next_query_update_since_datetime=datetime,
        )

    @classmethod
    def from_state(cls, state: State) -> Self:
        """
        Converts an operational stat to an iteration table item.

        Parameters
        ----------
        `state` : `State`
            The operational state.

        Returns
        -------
        `Self`
            The iteration table item.
        """

        # Set local variables.
        start_time = str(state.services_start_time)
        end_time = str(state.services_end_time)
        url = state.endpoint_url
        page_count = str(state.query_page_count)
        page_identifier = str(state.query_page_identifier)
        datetime = str(state.next_query_update_since_datetime)

        # Return an iteration table item.
        return cls(
            services_start_time=start_time,
            services_end_time=end_time,
            endpoint_url=url,
            query_page_count=page_count,
            query_page_identifier=page_identifier,
            next_query_update_since_datetime=datetime,
        )


@dataclass
class HistoricalTableItem(TableItem):
    """
    A class modeling an AWS DynamoDB historical table item.

    Attributes
    ----------
    `query_update_since_datetime` : `str`
        TBD.
    """

    # -- Attributes -- #

    query_update_since_datetime: str

    # -- Class Methods -- #

    @classmethod
    def from_iteration_table_item(cls, item: IterationTableItem):
        return cls(
            services_start_time=item.services_start_time,
            services_end_time=item.services_end_time,
            endpoint_url=item.endpoint_url,
            query_page_count=item.query_page_count,
            query_page_identifier=item.query_page_identifier,
            query_update_since_datetime=item.next_query_update_since_datetime,
        )

    @classmethod
    def from_state(cls, state: State) -> Self:
        """
        Converts an operational stat to a historical table item.

        Parameters
        ----------
        `state` : `State`
            The operational state.

        Returns
        -------
        `Self`
            The historical table item.
        """

        # Set local variables.
        start_time = str(state.services_start_time)
        end_time = str(state.services_end_time)
        url = state.endpoint_url
        page_count = str(state.query_page_count)
        page_identifier = str(state.query_page_identifier)
        datetime = str(state.query_update_since_datetime)

        # Return a historical table item.
        return cls(
            services_start_time=start_time,
            services_end_time=end_time,
            endpoint_url=url,
            query_page_count=page_count,
            query_page_identifier=page_identifier,
            query_update_since_datetime=datetime,
        )
