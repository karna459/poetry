"""
This module defines classes for managing CRUD operations (create, read, update,
and delete) on Snowflake database tables.

See:
1. https://betterprogramming.pub/9-python-dataclass-best-practices-to-improve-
   the-development-process-8a68df446580
2. https://community.snowflake.com/s/article/How-to-Use-Snowflake-with-AWS-
   Lambda
"""
from dataclasses import dataclass
from typing import Any
from typing import Union

import snowflake.connector as sfc


# TODO: Integrate this function into the `TableManager` class.


# SECTION: FUNCTIONS ======================================================== #


def format_value(value: Any) -> str:
    """
    Formats a record's field value for the Snowflake dialect of SQL.

    Parameters
    ----------
    `value` : `Any`
        A record's field value to format.

    Returns
    -------
    `str`
        The formatted value.
    """

    # Check the value's data type, and format it accordingly.
    if isinstance(value, set):
        return ' '.join(map(str, value))
    elif isinstance(value, str):
        return f"'{value}'"
    elif value is None:
        return 'NULL'
    else:
        return str(value)


# SECTION: CLASSES ========================================================== #


@dataclass
class TableManager:
    """
    This class enables CRUD (create, read, update delete) operations on a
    Snowflake table.

    Attributes
    ----------
    `account` : `str`
        Snowflake account name.
    `user` : `str`
        Snowflake username.
    `password` : `str`
        Snowflake password.
    `warehouse` : `str`
        Snowflake warehouse name.
    `database` : `str`
        Snowflake database name.
    `schema` : `str`
        Snowflake schema name.
    `table` : `str`
        Snowflake table name.
    `columns` : `list[str]`
        Snowflake table column names.
    """

    # -- Attributes -- #

    account: str
    user: str
    password: str

    warehouse: str
    database: str
    schema: str

    table: str
    columns: list[str]
    column_transformers: list[str]

    # -- Magic Methods -- #

    def __str__(self) -> str:
        """
        Renders a string representation of the table manager: the fully-
        qualified version of its table's name using dot notation.

        Returns
        -------
        `str`
            The string representation.
        """

        # Return the string representation.
        return f'{self.database}.{self.schema}.{self.table}'

    # -- Properties -- #

    @property
    def connection(self) -> sfc.connection.SnowflakeConnection:
        """
        Returns a Snowflake connection object.

        Returns
        -------
        `sfc.connection.SnowflakeConnection`
            A Snowflake connection object.
        """

        return sfc.connect(
            user=self.user,
            password=self.password,
            account=self.account,
            warehouse=self.warehouse,
            database=self.database,
            schema=self.schema,
        )

    @property
    def cursor(self) -> sfc.connection.SnowflakeConnection:
        """
        Returns a Snowflake cursor object.

        Returns
        -------
        `sfc.connection.SnowflakeConnection`
            A Snowflake cursor object.
        """

        return self.connection.cursor()

    # -- Magic Methods -- #

    def __enter__(self):
        return self.connection

    def __exit__(self, exc_type, exc_value, traceback):
        self.connection.close()

    # -- CRUD Methods -- #

    def create_table(
        self, execute: bool = False,
    ) -> str:
        """
        Creates a table in Snowflake if it doesn't exist.

        Returns
        -------
        `str`
            The CREATE statement.
        `execute` : `bool`
            Whether to execute the CREATE statement.
        """

        # Build the CREATE statement.
        sql = f'CREATE TABLE IF NOT EXISTS {self.table} (id INT, name STRING)'

        # Execute the CREATE statement.
        if execute:
            with self.cursor as cursor:
                cursor.execute(sql)

        # Return the CREATE statement.
        return sql

    def insert_record(
        self, record: tuple, execute: bool = False,
    ):
        """
        Insert one record into the table.

        Parameters
        ----------
        `record` : `tuple`
            A dictionary representing a record to insert.
        `execute` : `bool`
            Whether to execute the INSERT statement.

        Returns
        -------
        `str`
            The INSERT statement.
        """

        # Build the INSERT statement.
        formats = ['%s'] * len(self.columns)
        # sql = f'INSERT INTO {self.table} (id, name) VALUES (%s, %s)'
        sql = self.insert_select(
            self.table,
            self.column_transformers,
            formats,
        )

        # Execute the INSERT statement.
        if execute:
            with self.cursor as cursor:
                # cursor.execute(sql, (id_, name))
                cursor.execute(sql, record)

        # Return the INSERT statement.
        return sql

    def insert_records(
        self, records: list[tuple], execute: bool = False,
    ) -> str:
        """
        Insert multiple records into the table.

        Parameters
        ----------
        `records` : `list[tuple]`
            A list of dictionaries representing records to insert.
        `execute` : `bool`
            Whether to execute the INSERT statement.

        Returns
        -------
        `str`
            The INSERT statement.
        """

        # Build the INSERT statement.
        formats = ['%s'] * len(self.columns)
        sql = self.insert_select(
            self.table,
            self.column_transformers,
            formats,
        )

        # Execute the INSERT statement.
        if execute:
            with self.cursor as cursor:
                cursor.executemany(sql, records)

        # Return the INSERT statement.
        return sql

    def read_record(
        self, id_: int, execute: bool = False,
    ) -> Union[str, tuple]:
        """
        Reads a record from the table based on the provided ID.

        Parameters
        ----------
        `id_` : `int`
            The record's ID.
        `execute` : `bool`
            Whether to execute the SELECT statement.

        Returns
        -------
        `Union[str, tuple]`
            The SELECT statement or the record's details.
        """

        # Build the SELECT statement.
        sql = f'SELECT id, name FROM {self.table} WHERE id = %s'

        # Execute the SELECT statement.
        if execute:
            with self.cursor as cursor:
                cursor.execute(sql, (id_,))
                result = cursor.fetchone()

            # Return the record's details.
            return result

        # Return the SELECT statement.
        return sql

    def update_record(
        self, id_: int, new_name: str, execute: bool = False,
    ):
        """
        Updates the name in a record based on the provided ID.

        Parameters
        ----------
        `id_` : `int`
            The record's ID.
        `new_name` : `str`
            The record's new name.
        `execute` : `bool`
            Whether to execute the UPDATE statement.

        Returns
        -------
        `str`
            The UPDATE statement.
        """

        # Build the UPDATE statement.
        sql = f'UPDATE {self.table} SET name = %s WHERE id = %s'

        # Execute the UPDATE statement.
        if execute:
            with self.cursor as cursor:
                cursor.execute(sql, (new_name, id_))

        # Return the UPDATE statement.
        return sql

    def delete_record(
        self, id_: int, execute: bool = False,
    ):
        """
        Deletes a record from the table based on the provided ID.

        Parameters
        ----------
        `id_` : `int`
            The record's ID.
        `execute` : `bool`
            Whether to execute the DELETE statement.

        Returns
        -------
        `str`
            The DELETE statement.
        """

        # Build the DELETE statement.
        sql = f'DELETE FROM {self.table} WHERE id = %s'

        # Execute the DELETE statement.
        if execute:
            with self.cursor as cursor:
                cursor.execute(sql, (id_,))

        # Return the DELETE statement.
        return sql

    # -- SQL Methods -- #

    @staticmethod
    def insert_select(
        table: str, columns: list[str], values: list[str],
    ) -> str:
        """
        Returns an INSERT statement for the specified table and columns.

        Parameters
        ----------
        `table` : `str`
            The name of the table into which to insert records.
        `columns` : `list[str]`
            A list of column names.
        `values` : `list[str]`
            A list of values representing a record to insert.

        Raises
        ------
        `ValueError`
            If the number of columns in any record does not match the number of
            column names.

        Returns
        -------
        `str`
            The INSERT statement.

        Examples
        --------
        >>> table_name = "example_table"
        >>> columns = ["id", "name", "age"]
        >>> records = [
        >>>     {"id": 1, "name": "John", "age": 25},
        >>>     {"id": 2, "name": "Alice", "age": 30},
        >>>     {"id": 3, "name": "Bob", "age": 22},
        >>> ]
        >>> print(TableManager.insert_values(table_name, columns, records))
        INSERT INTO example_table (id, name, age) VALUES
        (1, 'John', 25),
        (2, 'Alice', 30),
        (3, 'Bob', 22);
        """

        # TODO: See if a list of tuples could replace a list of dictionaries.

        # Ensure the number of columns is consistent across all records.
        if len(values) != len(columns):
            msg = (
                'Number of values in records '
                'must match the specified columns.'
            )
            raise ValueError(msg)

        # Build the INSERT statement parts.
        columns_part = ', '.join(columns)
        # values_part = ', '.join(['%s'] * len(columns))
        values_part = ', '.join(values)

        # Build the INSERT statement.
        sql = (
            f'INSERT INTO {table} '
            f'SELECT {columns_part} '
            f'FROM VALUES ({values_part})'
        )

        # Return the INSERT statement.
        return sql + ';'

    @staticmethod
    def insert_values(
        table: str, columns: list[str], values: list[str],
    ) -> str:
        """
        Returns an INSERT statement for the specified table and columns.

        Parameters
        ----------
        `table` : `str`
            The name of the table into which to insert records.
        `columns` : `list[str]`
            A list of column names.
        `values` : `list[str]`
            A list of values representing a record to insert.

        Raises
        ------
        `ValueError`
            If the number of columns in any record does not match the number of
            column names.

        Returns
        -------
        `str`
            The INSERT statement.

        Examples
        --------
        >>> table_name = "example_table"
        >>> columns = ["id", "name", "age"]
        >>> records = [
        >>>     {"id": 1, "name": "John", "age": 25},
        >>>     {"id": 2, "name": "Alice", "age": 30},
        >>>     {"id": 3, "name": "Bob", "age": 22},
        >>> ]
        >>> print(TableManager.insert_values(table_name, columns, records))
        INSERT INTO example_table (id, name, age) VALUES
        (1, 'John', 25),
        (2, 'Alice', 30),
        (3, 'Bob', 22);
        """

        # TODO: See if a list of tuples could replace a list of dictionaries.

        # Ensure the number of columns is consistent across all records.
        if len(values) != len(columns):
            msg = (
                'Number of values in records '
                'must match the specified columns.'
            )
            raise ValueError(msg)

        # Build the INSERT statement parts.
        columns_part = ', '.join(columns)
        # values_part = ', '.join(['%s'] * len(columns))
        # values_part = ',\n'.join(
        #     ', '.join(map(format_value, record.values()))
        #     for record in records
        # )
        values_part = ', '.join(values)

        # Build the INSERT statement.
        sql = f'INSERT INTO {table} ({columns_part}) VALUES ({values_part})'

        # Return the INSERT statement.
        return sql + ';'
