"""
This module defines a class for managing the operational state of HTTP GET
response ingestion.

See:
1. https://betterprogramming.pub/9-python-dataclass-best-practices-to-improve-
   the-development-process-8a68df446580
"""
import os
from dataclasses import dataclass
from typing import Any
from typing import Self

import boto3
from boto3.resources.base import ServiceResource

from serviceslib.api.endpoint import Endpoint
from serviceslib.database.dynamodb import IterationTableItem
from serviceslib.ops.state import State


# SECTION: CONSTANTS ======================================================== #


# Environment variables
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')
HISTORICAL_TABLE = os.environ.get(
    'HISTORICAL_TABLE', default='MyHistoricalTable',
)
ITERATION_TABLE = os.environ.get(
    'ITERATION_TABLE', default='MyIterationTable',
)


# SECTION: CLASSES ========================================================== #


@dataclass
class StateManager:
    """
    This class enables operational state management of HTTP GET response
    ingestion.

    Attributes
    ----------
    `state` : `State`
        The current operational state.
    """

    # -- Attributes -- #

    state: State
    historical_table: ServiceResource
    iteration_table: ServiceResource

    # -- Magic Methods -- #

    def __post_init__(self) -> None:
        """
        Initializes the class instance.
        """

        # If both DynamoDB tables are empty....
        if self.has_empty_tables():

            # Define the item to put into the DynamoDB iteration table.
            item = IterationTableItem.from_state(self.state)

            # Put the item into the DynamoDB iteration table.
            self.iteration_table.put_item(Item=item.__dict__)

    # -- Properties -- #

    def has_empty_tables(self) -> bool:
        """
        Determines whether the class instance contains empty tables AWS
        DynamoDB tables.

        Returns
        -------
        `bool`
            `True` if the class instance contains empty tables; `False`
            otherwise.
        """

        # Filter for empty tables.
        tables = [self.historical_table, self.iteration_table]
        empty_tables = [t for t in tables if t.item_count == 0]

        # Return `True` if there are empty tables or `False` otherwise.
        return bool(empty_tables)

    # -- Magic Methods -- #

    def __str__(self) -> str:
        """
        Renders a string representation of the table manager: its operational
        state.

        Returns
        -------
        `str`
            The string representation.
        """

        # Return the string representation.
        return str(self.state)

    # -- Instance Methods -- #

    def end(self) -> None:
        """
        Sets the operational state to "end".
        """

        self.state.end()

    def next(self) -> None:
        """
        Sets the operational state to "next".
        """

        self.state.next()

    def reset(self) -> None:
        """
        Sets the operational state to "reset".
        """

        self.state.reset()

    def snap(self) -> None:
        """
        Sets the operational state to "snap".
        """

        self.state.snap()

    # -- Class Methods -- #

    @classmethod
    def from_config(
        cls, config: dict[str, Any],
    ) -> Self:
        """
        Creates a class instance from a dictionary representing configured
        settings.

        Parameters
        ----------
        `config` : `dict[str, Any]`
            The configuration.

        Returns
        -------
        `Self`
            The class instance.
        """

        # Parse the configuration.
        endpoint_cfg = config['endpoint']

        # Create the endpoint.
        endpoint = Endpoint(**endpoint_cfg)

        # Return the class instance.
        return cls.from_endpoint(endpoint)

    @classmethod
    def from_endpoint(
        cls, endpoint: Endpoint,
    ) -> Self:
        """
        Creates a class instance from a REST API endpoint.

        Parameters
        ----------
        `config` : `dict[str, Any]`
            The configuration.

        Returns
        -------
        `Self`
            The class instance.
        """

        # Return the class instance.
        return cls.from_endpoint_url(endpoint.url)

    @classmethod
    def from_endpoint_url(
        cls, endpoint_url: str,
    ) -> Self:
        """
        Creates a class instance from a REST API endpoint URL.

        Parameters
        ----------
        `endpoint_url` : `str`
            The REST API endpoint of an HTTP GET request.

        Returns
        -------
        `Self`
            The class instance.
        """

        # Create the starting operational state.
        state = State(endpoint_url)
        state.reset()

        # Create the AWS DynamoDB client.
        ddb = boto3.resource('dynamodb', region_name=AWS_REGION)

        # Create the AWS DynamoDB tables
        historical_table = ddb.Table(HISTORICAL_TABLE)
        iteration_table = ddb.Table(ITERATION_TABLE)

        # Return the class instance.
        return cls(state, historical_table, iteration_table)
