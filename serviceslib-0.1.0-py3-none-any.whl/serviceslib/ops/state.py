"""
This module defines a class modeling the operational state of HTTP GET response
ingestion.

See:
1. https://betterprogramming.pub/9-python-dataclass-best-practices-to-improve-
   the-development-process-8a68df446580
"""
from dataclasses import dataclass
from typing import Optional

from serviceslib.helpers.datetime import now


# SECTION: CLASSES ========================================================== #


@dataclass
class State:
    """
    A class modeling the operational state of HTTP GET response ingestion.

    Attributes
    ----------
    `endpoint_url` : `str`
        The REST API endpoint of an HTTP GET request.
    `next_query_update_since_datetime` : `str`
        TBD.
    `query_update_since_datetime` : `Optional[str]`
        TBD.
    `query_page_count` : `int`
        The page count of an HTTP GET request.
    `query_page_identifier` : `Optional[str]`
        An offset value used in an HTTP GET request to control pagination.
    `services_end_time` : `Optional[str]`
        The end time of an HTTP GET request.
    `services_start_time` : `Optional[str]`
        The start time of an HTTP GET request.
    """

    # -- Attributes -- #

    # Required
    endpoint_url: str

    # Optional
    next_query_update_since_datetime: Optional[str] = None
    query_update_since_datetime: Optional[str] = None
    query_page_count: int = 0
    query_page_identifier: Optional[str] = None
    services_end_time: Optional[str] = None
    services_start_time: Optional[str] = None

    # -- Magic Methods -- #

    def __str__(self) -> str:
        """
        Renders a string representation of the table manager: its operational
        state.

        Returns
        -------
        `str`
            The string representation.
        """

        # Build the string representation.
        state_str = ', '.join([
            f'{self.endpoint_url =}',
            f'{self.next_query_update_since_datetime =}',
            f'{self.query_update_since_datetime =}',
            f'{self.query_page_count =}',
            f'{self.query_page_identifier =}',
            f'{self.services_end_time =}',
            f'{self.services_start_time =}',
        ])

        # Return the string representation.
        return state_str

    # -- Instance Methods -- #

    def end(self) -> None:
        """
        Sets the operational state to "end".
        """

        self.services_end_time = now()

    def next(self) -> None:
        """
        Sets the operational state to "next".
        """

        services_start_time = self.services_start_time
        self.reset()
        self.next_query_update_since_datetime = services_start_time

    def reset(self) -> None:
        """
        Sets the operational state to "reset".
        """

        self.next_query_update_since_datetime = now()
        self.query_update_since_datetime = None
        self.query_page_count = 0
        self.query_page_identifier = None
        self.services_end_time = None
        self.services_start_time = None

    def snap(self) -> None:
        """
        Sets the operational state to "snap".
        """

        self.query_update_since_datetime = \
            self.next_query_update_since_datetime

    def start(self) -> None:
        """
        Sets the operational state to "start".
        """

        self.services_start_time = now()
