"""
Defines custom functions for datetime operations.

See:
1. https://www.iso.org/iso-8601-date-and-time-format.html
2. https://docs.python.org/3/library/datetime.html
3. https://en.wikipedia.org/wiki/ISO_8601
"""
from datetime import datetime


# SECTION: FUNCTIONS ======================================================== #


def now() -> str:
    """
    Returns the current UTC (Zulu time) datetime as a string formatted in the
    ISO 8601 standard (YYYY-MM-DDThh:mm:ss.sssZ).
    """

    return datetime.utcnow().isoformat() + 'Z'
