"""
Defines a class for managing retry attempts.

See:
1. https://betterprogramming.pub/9-python-dataclass-best-practices-to-improve-
   the-development-process-8a68df446580
2. https://changhsinlee.com/python-dataclass-mutable-default
3. https://exponentialbackoffcalculator.com
"""
from dataclasses import dataclass
from typing import Self


# SECTION: CLASSES ========================================================== #


@dataclass
class Retry:
    """
    A class modeling retry attempts.

    Attributes
    ----------
    `backoff_interval` : `int`
        The interval (sec) for calculating the backoff time.
    `backoff_max` : `int`
        The maximum backoff time (sec).
    `count` : `int` (optional)
        The number of retry attempts. Defaults to 0.
    `count_max` : `int` (optional)
        The maximum number of retry attempts. Defaults to 5.
    `rate` : `int` (optional)
        The exponential rate for calculating the backoff time. Defaults to 2.

    Methods
    -------
    `increment()` : `None`
        Increments the retry count by 1.
    """

    # -- Attributes -- #

    # Required attributes
    backoff_interval: int
    backoff_max: int

    # Optional attributes
    count: int = 0
    count_max: int = 5
    rate: int = 2

    # -- Properties -- #

    @property
    def backoff(self) -> int:
        """
        Returns the backoff time (sec).

        Returns
        -------
        `int`
            The backoff time (sec).
        """

        # Return the backoff time.
        return min(
            self.backoff_interval * (self.rate ** self.count),
            self.backoff_max,
        )

    @property
    def can_increment(self) -> bool:
        """
        Returns the result of a test to determine if the retry count can be
        incremented.

        Returns
        -------
        `bool`
            The test result.
        """

        # Return the test result.
        return self.count < self.count_max

    # -- Instance Methods -- #

    def increment(self) -> None:
        """
        Increments the retry count by 1.
        """

        self.count += 1

    # -- Class Methods -- #

    @classmethod
    def from_minutes(
        cls, backoff_interval: int, backoff_max: int,
        count: int = 0, count_max: int = 5, rate: int = 2,
    ) -> Self:
        """
        Creates a class instance from a JSON file.

        Parameters
        ----------
        `backoff_interval` : `int`
            The interval (sec) for calculating the backoff time.
        `backoff_max` : `int`
            The maximum backoff time (sec).
        `count` : `int` (optional)
            The number of retry attempts. Defaults to 0.
        `count_max` : `int` (optional)
            The maximum number of retry attempts. Defaults to 5.
        `rate` : `int` (optional)
            The exponential rate for calculating the backoff time. Defaults to
            2.


        Returns
        -------
        `Self`
            The class instance.
        """

        # Return the class instance.
        return cls(
            60*backoff_interval, 60*backoff_max,
            count, count_max, rate,
        )
