"""
Defines custom functions for JSON operations.

See:
1. https://docs.python.org/3/library/json.html
"""
import json
from typing import List
from typing import Optional


# SECTION: FUNCTIONS ======================================================== #


def find_first_list(
    data: dict, search_type: str = 'breadth-first',
) -> Optional[list]:
    """
    Returns a list from a dictionary.

    Parameters
    ----------
    `data` : `dict`
        A dictionary.
    `search_type` : `str`, optional
        The type of search to perform. Valid values are 'depth-first' and
        'breadth-first'. Default is 'breadth-first'.

    Returns
    -------
    `Optional(list)`
        The list if one is found.

    Raises
    ------
    `ValueError`
        If the dictionary does not contain a list.

    Examples
    --------
    >>> my_dict = {
    >>>     'key1': [1, 2, 3],
    >>>     'key2': {'key3': [4, 5, 6], 'key4': {'key5': [7, 8, 9]}},
    >>>     'key6': {'key7': 'not a list'}
    >>> }
    >>> print(find_first_list(my_dict, 'breadth-first'))
    [1, 2, 3]
    >>> print(find_first_list(my_dict, 'depth-first'))
    [4, 5, 6]
    """

    if isinstance(data, list):
        return data

    if search_type == 'breadth-first':
        queue = list(data.values())
        while queue:
            current = queue.pop(0)
            if isinstance(current, list):
                return current
            elif isinstance(current, dict):
                queue.extend(current.values())
    elif search_type == 'depth-first':
        for value in data.values():
            result = find_first_list(value, search_type)
            if result:
                return result

    return None


def split_json_array(json_str: str) -> List[str]:
    """
    Returns a list of JSON strings from a JSON string containing an array.

    Parameters
    ----------
    `json_str` : `str`
        A string representing a JSON object containing an array.

    Returns
    -------
    `List[str]`
        A list of JSON strings.

    Raises
    ------
    `ValueError`
        If the JSON string does not contain an array.

    Examples
    --------
    >>> json_str1 = '{"data": [{"id": 1, "name": "Alice"}, {"id": 2, "name": \
    >>>     "Bob"}], "info": "example"}'
    >>> print(split_json_array(json_str1))
    ['{"id": 1, "name": "Alice"}', '{"id": 2, "name": "Bob"}']
    """

    # Parse the JSON string into a Python dictionary.
    data = json.loads(json_str)

    # Identify the top-level key that contains the JSON array.
    array_key = None
    for key, value in data.items():
        if isinstance(value, list):
            array_key = key
            break

    # Check if a JSON array key was found.
    if array_key is None:
        raise ValueError('No array found in the JSON structure.')

    # Split the array into individual elements.
    array_elements = data[array_key]

    # Convert each element back into a JSON string.
    split_strings = [json.dumps(element) for element in array_elements]

    # Return the list of JSON strings.
    return split_strings
