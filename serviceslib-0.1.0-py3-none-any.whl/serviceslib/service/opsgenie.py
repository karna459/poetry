"""
Defines a class for managing Opsgenie operations.

See:
1. https://betterprogramming.pub/9-python-dataclass-best-practices-to-improve-
   the-development-process-8a68df446580
2. https://changhsinlee.com/python-dataclass-mutable-default
3. https://github.com/opsgenie/opsgenie-python-sdk
4. https://docs.opsgenie.com/docs/opsgenie-python-api-v2-1
"""
from typing import Self

import opsgenie_sdk as og

from serviceslib.service.parameter import Setting


# SECTION: CONSTANTS ======================================================== #


API_KEY_PARAMETER_NAME = '/incident_alerting/api_key'


# SECTION: CLASSES ========================================================== #


class Opsgenie:
    """
    A class modeling an Opsgenie client.
    """

    # -- Magic Methods -- #

    def __init__(self, api_key: str):
        """
        The class constructor.

        Parameters
        ----------
        `api_key` : `str`
            A string representing an OpsGenie API key.
        """

        self.conf = og.configuration.Configuration()
        self.conf.api_key['Authorization'] = api_key

        self.api_client = og.api_client.ApiClient(configuration=self.conf)
        self.alert_api = og.AlertApi(api_client=self.api_client)

    # -- Instance Methods -- #

    def create_alert(
        self, alert_payload: og.Alert,
    ) -> og.models.success_response.SuccessResponse | None:
        """
        Sends an Opsgenie alert.

        Parameters
        ----------
        `alert_payload` : `Alert`
            A dictionary representing an Opsgenie alert payload.

        Returns
        -------
        `og.models.success_response.SuccessResponse | None`
            The Opsgenie alert response.
        """

        # Try to send the Opsgenie alert.
        try:
            # Send the Opsgenie alert.
            resp = self.alert_api.create_alert(alert_payload)

            # Log the response status code
            print(f'Opsgenie alert sent. Request ID: {resp.request_id}')

            # Return the response.
            return resp

        # Handle an Opsgenie API error.
        except og.ApiException as e:
            print(f'API Error: Failed to send Opsgenie alert: {e}')
            return None

        # Handle unexpected errors.
        except Exception as e:
            print(f'Error: {e}')
            return None

    # -- Class Methods -- #

    @classmethod
    def from_parameter(cls) -> Self:
        """
        Creates a class instance from an AWS Parameter Store parameter name.

        Returns
        -------
        `Self`
            The class instance.
        """

        # Return the class instance.
        return cls(str(Setting(API_KEY_PARAMETER_NAME)))
