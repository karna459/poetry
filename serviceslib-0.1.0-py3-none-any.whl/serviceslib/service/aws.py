"""
Defines custom constants and functions for AWS operations.

See:
1. https://docs.python.org/3/library/os.html
2. https://repost.aws/questions/QUidOETC17R2Cf5vTawtgBpA/can-someone-explain-
   the-point-of-messagegroupid
"""
import json
import os
from typing import Any

import boto3
from boto3.resources.base import ServiceResource


# SECTION: CONSTANTS ======================================================== #


# Environment variables
CONFIG = os.environ.get('CONFIG', '')
READ_QUEUE_URL = os.environ.get('READ_QUEUE_URL', '')
WRITE_QUEUE_URL = os.environ.get('WRITE_QUEUE_URL', '')
SCHEDULER_NAME = os.environ.get('EVENTBRIDGE_SCHEDULER_NAME', '')
HISTORICAL_TABLE_NAME = os.environ.get('HISTORICAL_TABLE_NAME', '')
ITERATION_TABLE_NAME = os.environ.get('ITERATION_TABLE_NAME', '')

# AWS clients
DDB = boto3.resource('dynamodb')
EVENTS = boto3.client('events')
LAMBDA = boto3.client('lambda')
SQS = boto3.client('sqs')
SSM = boto3.client('ssm')

# AWS resources
HISTORICAL_TABLE = DDB.Table(HISTORICAL_TABLE_NAME)
ITERATION_TABLE = DDB.Table(ITERATION_TABLE_NAME)


# SECTION: FUNCTIONS ======================================================== #


# - Data Management - #

def has_empty_tables(tables: list[ServiceResource]) -> bool:
    """
    Determines whether a list of DynamoDB tables contains empty tables.

    Parameters
    ----------
    `tables` : `list[Table]`
        A list of AWS DynamoDB tables.

    Returns
    -------
    `bool`
        `True` if the list contains empty tables; `False` otherwise.
    """

    # Filter for empty tables.
    empty_tables = [t for t in tables if t.item_count == 0]

    # Return `True` if there are empty tables or `False` otherwise.
    return bool(empty_tables)


# -- Logging -- #

def log_lambda_preflight(
    event: dict, context: Any,
) -> None:
    """
    Logs information about the AWS Lambda function's preflight state.

    Parameters
    ----------
    `event` : `dict`
        The AWS Lambda function's event.
    `context` : `Any`
        The AWS Lambda function's context.
    """

    # Log some information from the context.
    print('Function name:', context.function_name)
    print('Function version:', context.function_version)
    print('Log group name:', context.log_group_name)
    print('Log stream name', context.log_stream_name)
    print('Memory limit in MB:', context.memory_limit_in_mb)

    # Log other useful information from the context.
    print('AWS request ID:', context.aws_request_id)
    print('Invoked function ARN:', context.invoked_function_arn)

    # Print the request.
    print('Event:', json.dumps(event))

    # Log environment variables.
    for key, value in os.environ.items():
        if not key.startswith('AWS_'):
            print(f'{key} = {value}')


# -- Messaging -- #


def change_message_visibility(
    event: dict,
    timeout: int,
    queue_prefix: str = '',
) -> None:
    """
    Changes the visibility timeout of a message in an AWS SQS queue.

    Parameters
    ----------
    `event` : `dict`
        A JSON-formatted document that contains data for an AWS Lambda
        function.
    `timeout` : `int`
        The new visibility timeout (sec).
    `queue_prefix` : `str`, optional
        The prefix of the AWS SQS queue's name, defaults to an empty string.
    """

    print(
        'Changing visibility timeout of message ',
        f'in AWS SQS {queue_prefix} queue...',
    )

    # Try to change the visibility timeout of the new message.
    try:
        # Change the visibility timeout of the new message
        SQS.change_message_visibility(
            QueueUrl=event['QueueUrl'],
            ReceiptHandle=event['ReceiptHandle'],
            VisibilityTimeout=timeout,
        )

    # Handle unexpected errors.
    except Exception as e:
        print(f'Visibility Change Error: {e}')


def delete_message(
    event: dict,
    queue_url: str,
    queue_prefix: str = '',
) -> None:
    """
    Deletes a message from an AWS SQS queue.

    Parameters
    ----------
    `event` : `dict`
        A JSON-formatted document that contains data for an AWS Lambda function
        to process.
    `queue_url` : `str`
        The URL of the AWS SQS queue.
    `queue_prefix` : `str`, optional
        The prefix of the AWS SQS queue's name, defaults to an empty string.
    """

    print(
        'Deleting message '
        f'from AWS SQS {queue_prefix} queue...',
    )

    # Parse the request.
    record = event['Records'][0]

    # Delete the message from the AWS SQS queue.
    SQS.delete_message(
        QueueUrl=queue_url,
        ReceiptHandle=record['receiptHandle'],
    )
    print(
        f'Message deleted from AWS SQS {queue_prefix} queue. Message ID:',
        record['messageId'],
    )


def send_message(
    body: str,
    queue_url: str,
    queue_prefix: str = '',
) -> None:
    """
    Sends a message to an AWS SQS queue.

    Parameters
    ----------
    `body` : `str`
        The message body.
    `queue_url` : `str`
        The URL of the AWS SQS queue.
    `queue_prefix` : `str`, optional
        The prefix of the AWS SQS queue's name, defaults to an empty string.
    """

    print(
        'Sending message '
        f'to AWS SQS {queue_prefix} queue...',
    )

    # Send the message to the AWS SQS queue.
    response = SQS.send_message(
        QueueUrl=queue_url,
        MessageBody=body,
        MessageGroupId='default-group',
    )
    print(f'{response = }')
    print(
        f'Message sent to AWS SQS {queue_prefix} queue. Message ID:',
        response['MessageId'],
    )
