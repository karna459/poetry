"""
This module defines classes for managing settings and secrets.

See:
1. https://docs.aws.amazon.com/systems-manager/latest/userguide/systems-
   manager-parameter-store.html
2. https://betterprogramming.pub/9-python-dataclass-best-practices-to-improve-
   the-development-process-8a68df446580
"""
import abc
from dataclasses import dataclass

import boto3


# SECTION: CONSTANTS ======================================================== #


SECRETS = boto3.client('secretsmanager')
SSM = boto3.client('ssm')


# SECTION: CLASSES ========================================================== #


@dataclass
class Parameter(abc.ABC):
    """
    Represents a parameter-like AWS resource.

    Parameters
    ----------
    `name` : `str`
        The parameter's name.
    """

    # -- Attributes -- #

    name: str

    # -- Properties -- #

    @property
    @abc.abstractmethod
    def arn(self) -> str:
        """
        Abstract property to get the parameter's ARN (Amazon Resource Name).

        Returns
        -------
        `str`
            The parameter's ARN.
        """

        raise NotImplementedError('Subclasses must implement this method.')

    @property
    @abc.abstractmethod
    def value(self) -> str:
        """
        Abstract property to get the parameter's value.

        Returns
        -------
        `str`
            The parameter's value.
        """

        raise NotImplementedError('Subclasses must implement this method.')

    # -- Magic Methods -- #

    def __str__(self) -> str:
        """
        Renders a string representation of the parameter: its value.

        Returns
        -------
        `str`
            The string representation.
        """

        # Return the string representation.
        return self.value


@dataclass
class Setting(Parameter):
    """
    Represents an AWS Parameter Store setting (i.e., parameter).

    Parameters
    ----------
    `name` : `str`
        The setting's name.
    """

    # -- Attributes -- #

    name: str

    # -- Properties -- #

    @property
    def _response(self) -> dict:
        """
        Gets the response from the attempt to get the setting.

        Returns
        -------
        `dict`
            The response.
        """

        try:
            # Get the response.
            return SSM.get_parameter(Name=self.name, WithDecryption=True)
        except SSM.exceptions.ParameterNotFound as e:
            # Raise an exception if the setting is not found.
            print(f'Error: {e}')
            raise ValueError(f'Setting "{self.name}" is not found.') from e
        except Exception as e:
            # Raise an exception if an unexpected error occurs.
            print(f'Error: {e}')
            raise e

    @property
    def arn(self) -> str:
        """
        Gets the setting's ARN (Amazon Resource Name).

        Returns
        -------
        `str`
            The setting's ARN.
        """

        # Return the extracted setting ARN.
        return self._response['Parameter']['ARN']

    @property
    def value(self) -> str:
        """
        Get's the setting's value.

        Returns
        -------
        `str`
            The setting's value.
        """

        # Return the extracted parameter value.
        return self._response['Parameter']['Value']


@dataclass
class Secret(Parameter):
    """
    Represents an AWS Secrets Manager secret.

    Parameters
    ----------
    `name` : `str`
        The secret's name.
    """

    # -- Attributes -- #

    name: str

    # -- Properties -- #

    @property
    def _response(self) -> dict:
        """
        Gets the response from the attempt to get the secret.

        Returns
        -------
        `dict`
            The response.
        """

        try:
            # Get the response.
            return SECRETS.get_secret_value(SecretId=self.name)
        except SECRETS.exceptions.ResourceNotFoundException as e:
            # Raise an exception if the secret is not found.
            print(f'Error: {e}')
            raise ValueError(f'Secret "{self.name}" is not found.') from e
        except Exception as e:
            # Raise an exception if an unexpected error occurs.
            print(f'Error: {e}')
            raise e

    @property
    def arn(self) -> str:
        """
        Get the secret's ARN (Amazon Resource Name).

        Returns
        -------
        `str`
            The secret's ARN.
        """

        # Return the extracted secret's ARN.
        return self._response['ARN']

    @property
    def value(self) -> str:
        """
        Get the secret's value.

        Returns
        -------
        `str`
            The secret's value.
        """

        # Return the extracted secret value.
        return self._response['SecretString']
